from pythonProject.m14_kalender import Kalender
from pythonProject.m15_uhr import Uhr

# Die Klasse KalenderUhr erbt von den Klassen Kalender und Uhr.
# Das bedeutet praktisch: Alle Eigenschaften und Methoden aus den Klassen
# Kalender und Uhr stehen in der Klasse KalenderUhr zur Verfügung.
class KalenderUhr(Kalender, Uhr):
    def __init__(self, tag, monat, jahr, stunde, minute, sekunde):
        Kalender.__init__(self, jahr, monat, tag)
        Uhr.__init__(self, stunde, minute, sekunde)

    def __repr__(self):
        return Kalender.__repr__(self) + " " + Uhr.__repr__(self)

    def naechsteSekunde(self):
        Uhr.naechsteSekunde(self)
        if (self.stunde, self.minute, self.sekunde) == (0, 0, 0):
            Kalender.naechsterTag(self)


ku = KalenderUhr(4, 7, 2024, 23, 59, 59)
print(ku)
ku.naechsteSekunde()
print(ku)
ku.naechsterTag()
print(ku)
