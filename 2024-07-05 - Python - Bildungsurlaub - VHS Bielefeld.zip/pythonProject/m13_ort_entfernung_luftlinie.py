from geopy.geocoders import Nominatim
from geopy import distance

orte = ["Bad Salzuflen", "Dietzenbach", "Bielefeld", "Bielefeld", "Spenge", "Bielefeld", "Bielefeld",
        "Schloss Holte-Stukenbrock", "Berlin", "Hannover", "Bielefeld", "Bielefeld"]

orte = set(orte)
ziel = "Bielefeld"
orte.remove(ziel)

# Frage: Welcher Ort aus der Menge der orte ist am weitesten vom ziel "Bielefeld" entfernt (Luftlinie)?
geolocator = Nominatim(user_agent="vhs_bielefeld_python_daniel")
# locations = geolocator.geocode("McDonald's Bielefeld", exactly_one=False)
# print(*locations, sep="\n")
location = geolocator.geocode(ziel)
latlong_ziel = (location.latitude, location.longitude)

distanz_liste = []
for ort in orte:
    location = geolocator.geocode(ort)
    latlong = (location.latitude, location.longitude)
    distanz = distance.distance(latlong_ziel, latlong).km
    distanz_liste.append((distanz, ort))

print(*distanz_liste, sep="\n")
print()
print(max(distanz_liste))
