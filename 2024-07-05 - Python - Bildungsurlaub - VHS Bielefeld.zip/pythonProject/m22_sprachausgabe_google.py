from gtts import gTTS
import playsound3

# Setze den Text, der gesprochen werden soll
text = "Hallo, wie geht's Dir?"

# Erzeuge die Sprachdatei
tts = gTTS(text=text, lang='de')

# Speichere die Sprachdatei
tts.save("output.mp3")

# Spiele die Sprachdatei ab
playsound3.playsound("output.mp3")
