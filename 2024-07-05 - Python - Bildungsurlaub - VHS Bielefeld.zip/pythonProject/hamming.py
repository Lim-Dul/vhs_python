def hamming_distance(str_a, str_b):
    dist = 0
    for i in range(len(str_a)):
        if str_a[i] != str_b[i]:
            dist += 1

    return dist

def hamming_distance(str_a, str_b):
    dist = 0
    print(list(zip(str_a, str_b)))
    for a, b in zip(str_a, str_b):
        if a != b:
            dist += 1

    return dist

str_a = "ABC"
str_b = "ABD"
#        012

print(hamming_distance(str_a, str_b))