# Fibonacci-Zahlen:
# Die nächste Zahl der Folge ist die Summe der beiden vorhergehenden Zahlen der Folge.
# fib(n) 1 1 2 3 5 8 13 21
# n      0 1 2 3 4 5 6  7

# a b   a + b
# 1 1 | 2
# 1 2 | 3
# 2 3 | 5
# 3 5 | 8
# ...

# Iterative (d.h. schleifenbasierte) Lösung
def fib(n):
    a, b = 1, 1
    for i in range(n):
        a, b = b, a + b

    return a

print(fib(7))
print(fib(700))

# Rekursive Lösung (Rekursion: Eine Funktion, die sich selbst aufruft)
# Die nächste Zahl der Folge ist die Summe der beiden vorhergehenden Zahlen der Folge.
# fib(n) = fib(n - 1) + fib(n - 2)  für n >= 2 # rekursive Definition
# fib(0) = 1
# fib(1) = 1
def fib_rekursiv(n):
    if n >= 2:
        return fib_rekursiv(n - 1) + fib_rekursiv(n - 2)
    else:
        return 1

print(fib_rekursiv(7))
#print(fib_rekursiv(42))

d = {}
def fib_rekursiv_memo(n):
    if n in d:  # Haben wir den Wert für n schon einmal berechnet?
        return d[n]  # Wenn ja: Gib diesen einfach nach, indem Du ihn im Wörterbuch nachschlägst.

    if n >= 2:
        d[n] = fib_rekursiv_memo(n - 1) + fib_rekursiv_memo(n - 2)
        return d[n]
    else:
        return 1

print(fib_rekursiv_memo(7))
print(fib_rekursiv_memo(900))

###

def hanoi(n, start, hilf, ziel):
    if n == 0:
        return
    hanoi(n - 1, start, ziel, hilf)
    print("Bewege Scheibe", n, "von", start, "nach", ziel)
    hanoi(n - 1, hilf, start, ziel)

hanoi(5, "a", "b", "c")
