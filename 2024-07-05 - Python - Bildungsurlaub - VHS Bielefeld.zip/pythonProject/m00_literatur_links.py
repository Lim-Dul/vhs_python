# Python Tutor - Visualisierung von Python-Code:
# https://pythontutor.com/
#
# Online verfügbare Bücher:
# A Byte of Python: https://python.swaroopch.com/
# Fortgeschritten: Dive Into Python: https://diveintopython3.net/
# Tutorials von Bernd Klein (auf Deutsch und Englisch):
#   https://www.python-kurs.eu/
#   https://python-course.eu/python-tutorial/
#
# Begleitete Übungen:
# https://exercism.org/tracks
#
# Teilnehmenden-Vorschläge:
# Timeit
# Spiel: Schiffe versenken 1, TicTacToe 1, Snake 2, Schach
