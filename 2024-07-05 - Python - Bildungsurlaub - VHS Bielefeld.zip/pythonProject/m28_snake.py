import pygame
import time
import random

# Initialisiere pygame
pygame.init()

# Bildschirmgröße und Farben
SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (213, 50, 80)
BLACK = (0, 0, 0)
BLUE = (50, 153, 213)

# Setze die Bildschirmgröße und den Titel
game_display = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Snake Game')

# Snake Größe und Geschwindigkeit
SNAKE_BLOCK = 10
SNAKE_SPEED = 15

# Uhr für das Spiel
clock = pygame.time.Clock()

# Schriftart für das Spiel
font_style = pygame.font.SysFont(None, 50)

# Funktion zum Zeichnen der Schlange
def draw_snake(snake_block, snake_list):
    for x in snake_list:
        pygame.draw.rect(game_display, GREEN, [x[0], x[1], snake_block, snake_block])

# Funktion für die Anzeige des Spieltextes
def message(msg, color):
    mesg = font_style.render(msg, True, color)
    game_display.blit(mesg, [SCREEN_WIDTH / 6, SCREEN_HEIGHT / 3])

# Die Hauptspiel-Funktion
def gameLoop():
    game_over = False
    game_close = False

    # Snake Startposition
    x1 = SCREEN_WIDTH / 2
    y1 = SCREEN_HEIGHT / 2

    # Snake Bewegung
    x1_change = 0
    y1_change = 0

    # Snake Größe und Bewegungsliste
    snake_List = []
    Length_of_Snake = 1

    # Lebensmittel-Position
    foodx = round(random.randrange(0, SCREEN_WIDTH - SNAKE_BLOCK) / 10.0) * 10.0
    foody = round(random.randrange(0, SCREEN_HEIGHT - SNAKE_BLOCK) / 10.0) * 10.0

    # Hauptspiel-Schleife
    while not game_over:

        while game_close == True:
            game_display.fill(BLUE)
            message("You Lost! Press Q-Quit or C-Play Again", RED)
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        game_over = True
                        game_close = False
                    if event.key == pygame.K_c:
                        gameLoop()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    x1_change = -SNAKE_BLOCK
                    y1_change = 0
                elif event.key == pygame.K_RIGHT:
                    x1_change = SNAKE_BLOCK
                    y1_change = 0
                elif event.key == pygame.K_UP:
                    y1_change = -SNAKE_BLOCK
                    x1_change = 0
                elif event.key == pygame.K_DOWN:
                    y1_change = SNAKE_BLOCK
                    x1_change = 0

        if x1 >= SCREEN_WIDTH or x1 < 0 or y1 >= SCREEN_HEIGHT or y1 < 0:
            game_close = True
        x1 += x1_change
        y1 += y1_change
        game_display.fill(BLUE)
        pygame.draw.rect(game_display, BLACK, [foodx, foody, SNAKE_BLOCK, SNAKE_BLOCK])
        snake_Head = []
        snake_Head.append(x1)
        snake_Head.append(y1)
        snake_List.append(snake_Head)
        if len(snake_List) > Length_of_Snake:
            del snake_List[0]

        for x in snake_List[:-1]:
            if x == snake_Head:
                game_close = True

        draw_snake(SNAKE_BLOCK, snake_List)

        pygame.display.update()

        if x1 == foodx and y1 == foody:
            foodx = round(random.randrange(0, SCREEN_WIDTH - SNAKE_BLOCK) / 10.0) * 10.0
            foody = round(random.randrange(0, SCREEN_HEIGHT - SNAKE_BLOCK) / 10.0) * 10.0
            Length_of_Snake += 1

        clock.tick(SNAKE_SPEED)

    pygame.quit()
    quit()

# Starte das Spiel
gameLoop()
