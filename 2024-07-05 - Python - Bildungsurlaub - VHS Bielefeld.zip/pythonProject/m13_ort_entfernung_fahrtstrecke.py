import requests
import geopy

geolocator = geopy.Nominatim(user_agent="vhs_bielefeld_python_daniel")

start = "Bielefeld"
start_location = geolocator.geocode(start)
start_longlat = (start_location.latitude, start_location.longitude)

orte = ["Bad Salzuflen", "Dietzenbach", "Bielefeld", "Bielefeld", "Spenge", "Bielefeld", "Bielefeld",
        "Schloss Holte-Stukenbrock", "Berlin", "Hannover", "Bielefeld", "Bielefeld"]

orte = set(orte)
orte.remove(start)

# Frage: Welcher Ort aus der Menge der orte ist am weitesten vom ziel "Bielefeld" entfernt (Fahrtstrecke)?

distanz_liste = []
for ort in orte:
    ziel_location = geolocator.geocode(ort)
    ziel_longlat = (ziel_location.latitude, ziel_location.longitude)
    # URL für OSRM-Server
    url = f"http://router.project-osrm.org/route/v1/driving/{start_longlat[1]},{start_longlat[0]};{ziel_longlat[1]},{ziel_longlat[0]}?overview=false"
    # Anfrage an den OSRM-Server
    response = requests.get(url)
    data = response.json()
    # Fahrstrecke in Kilometern
    distanz = data['routes'][0]['distance'] / 1000
    # Distanz und Ort zur Liste hinzufügen
    distanz_liste.append((distanz, ort))

print(*distanz_liste, sep="\n")
print()
print(max(distanz_liste))
