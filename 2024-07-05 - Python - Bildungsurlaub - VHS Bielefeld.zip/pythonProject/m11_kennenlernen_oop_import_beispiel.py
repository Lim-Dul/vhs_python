from datetime import date
from pythonProject.m11_kennenlernen_oop import Teilnehmer

t1 = Teilnehmer("Felix", date(1994, 12, 1), "Bad Salzuflen")
t2 = Teilnehmer("Jan", date(1983, 7, 4), "Dietzenbach")
