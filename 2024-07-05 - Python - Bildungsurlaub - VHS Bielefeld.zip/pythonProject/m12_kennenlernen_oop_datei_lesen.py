import pandas as pd
from datetime import date, datetime


class Teilnehmer(object):
    def __init__(self, vorname, geburtsdatum, ort):
        self.vorname = vorname
        self.geburtsdatum = geburtsdatum
        self.ort = ort

    def alter(self):
        datum = self.geburtsdatum
        heute = date.today()
        jahre = heute.year - datum.year
        if (heute.month, heute.day) < (datum.month, datum.day):  # hatte er noch nicht Geburtstag?
            jahre -= 1

        return jahre

# Pandas liest die CSV-Datei in sein eigenes internes tabellenartiges Format ein, das man DataFrame nennt.
dateiname = "teilnehmer.csv"
df = pd.read_csv(dateiname)
print(df)

# Umwandeln des DataFrame in unsere objektorientierte auf der Klasse Teilnehmer basierende Darstellung
teilnehmerliste = []
for _, teilnehmer in df.iterrows():
    datum = datetime.strptime(teilnehmer["Geburtsdatum"], "%Y-%m-%d").date()
    teilnehmerliste.append(Teilnehmer(teilnehmer["Vorname"], datum, teilnehmer["Ort"]))

# Wie alt ist der erste Teilnehmer in der Liste?
print(teilnehmerliste[0].alter())

# Felix zieht nach Frankfurt um:
idx = [teilnehmer.vorname for teilnehmer in teilnehmerliste].index("Felix")
teilnehmerliste[idx].ort = "Frankfurt"

# Abspeichern der Teilnehmer in der CSV-Datei ("Boilerplate code")
liste = []
for teilnehmer in teilnehmerliste:
    d = {"Vorname": teilnehmer.vorname, "Geburtsdatum": teilnehmer.geburtsdatum, "Ort": teilnehmer.ort}
    liste.append(d)

df = pd.DataFrame(liste)
df.to_csv(dateiname)
