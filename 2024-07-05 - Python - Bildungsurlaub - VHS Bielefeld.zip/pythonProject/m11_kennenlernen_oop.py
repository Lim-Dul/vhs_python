from datetime import date

class Teilnehmer(object):
    def __init__(self, vorname, geburtsdatum, ort):
        self.vorname = vorname
        self.geburtsdatum = geburtsdatum
        self.ort = ort

    def alter(self):
        datum = self.geburtsdatum
        heute = date.today()
        jahre = heute.year - datum.year
        if (heute.month, heute.day) < (datum.month, datum.day):  # hatte er noch nicht Geburtstag?
            jahre -= 1

        return jahre


t1 = Teilnehmer("Felix", date(1994, 12, 1), "Bad Salzuflen")
t2 = Teilnehmer("Jan", date(1983, 7, 4), "Dietzenbach")

teilnehmerliste = [t1, t2]

# Wie alt ist der erste Teilnehmer in der Liste?
print(teilnehmerliste[0].alter())

# Berechne das Durchschnittsalter der Teilnehmer in der teilnehmerliste:
# a) for-Schleife
# summe, anzahl = 0, 0
summe = 0
anzahl = 0

# Lies: Für (for) jedes alter in der Liste der altersangaben wiederhole die nachfolgenden Anweisungen im eingerückten Block
for teilnehmer in teilnehmerliste:
    summe += teilnehmer.alter()  # Kurz für: summe = summe + alter
    anzahl += 1  # Kurz für: anzahl = anzahl + 1

durchschnitt = summe / anzahl
print("Durchschnittsalter:", durchschnitt)

# b) Zwischenüberlegung: Wie bekomme ich eine Liste der Altersangaben?
altersangaben = []
for teilnehmer in teilnehmerliste:
    altersangaben.append(teilnehmer.alter())

print(sum(altersangaben) / len(altersangaben))

# c) List Comprehension
altersangaben = [teilnehmer.alter() for teilnehmer in teilnehmerliste]
print(sum(altersangaben) / len(altersangaben))
