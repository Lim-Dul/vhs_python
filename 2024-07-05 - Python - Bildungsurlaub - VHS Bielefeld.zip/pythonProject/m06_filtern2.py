temperaturen = [-12, 5, 23, 17, 25]
vornamen = ["Anna", "Peter", "Gabi"]

def filtern(liste, lb):
    gefiltert = []
    for element in liste:
        if element >= lb:
            gefiltert.append(element)

    return gefiltert

print(filtern(temperaturen, 20))
# print(filtern(temperaturen, ">=20 und <=30 und teilbar durch 2"))
# print(filtern(emails, "mit Anhang"))
print(filtern(temperaturen, 10))
print(filtern(vornamen, "G"))
