from datetime import datetime

import pandas as pd
import requests
import locale

locale.setlocale(locale.LC_ALL, 'de_DE.UTF-8')

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0"
}

url1 = "https://www.amazon.de/LEGO-75288-Action-Set-kreatives-Spielerlebnis/dp/B0813Q5JKX/"
url2 = "https://www.amazon.de/Dive-Into-Python-Books-Professionals/dp/1430224150/"
urls = [url1, url2]

prices = {}

for url in urls:
    res = requests.get(url, headers=headers)
    txt = res.text

    price_key = "displayPrice"
    pos_start = txt.index(price_key)
    pos_ende = txt.index("€", pos_start)
    price_txt = txt[pos_start + len(price_key) + 3:pos_ende - 1]
    price = locale.atof(price_txt)
    prices[url] = price

print(prices)
df = pd.DataFrame((url, price, datetime.now()) for url, price in prices.items())
df.to_excel("prices.xlsx")
