import datetime
import matplotlib.pyplot as plt
from geopy import Nominatim
from metno_locationforecast import Place, Forecast

ort = "Bielefeld"
agent = "vhs_bielefeld_python_daniel"

# Geopy
geolocator = Nominatim(user_agent=agent)
location = geolocator.geocode(ort)

# Metno
place = Place(ort, location.latitude, location.longitude)
forecast = Forecast(place, agent)
forecast.update()

# Listen fürs Plotten vorbereiten
times = []
temperatures = []

for interval in forecast.data.intervals_for(datetime.date.today()):
    times.append(interval.start_time.hour)
    temperatures.append(interval.variables["air_temperature"].value)

# Erstelle das Liniendiagramm
plt.plot(times, temperatures, marker='o', linestyle='-', color='b')

# Beschrifte die Achsen
plt.xlabel('Uhrzeit')
plt.ylabel('Temperatur (°C)')

# Titel hinzufügen
plt.title('Temperaturverlauf im Laufe des Tages')

# Zeige das Diagramm an
plt.grid(True)
plt.show()
plt.savefig("diagramm.png")