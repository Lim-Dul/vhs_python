import logging
from timeit_decorator import timeit

satz = "shgsajklhgsjfghaskjfljrqghkljsdfhgloiurwhjrhgoasjfhgkjsfdhgkjfhgkjdfhgkjdhfgkjlhdfgkkljdfhgtrziothz"

@timeit(runs=5, workers=2, log_level=logging.INFO)
def variante1():
    for zeichen in sorted(set(satz)):
        print(zeichen, satz.count(zeichen))

@timeit()
def variante2():
    strichliste = {}  # leeres Wörterbuch
    for zeichen in satz:
        if zeichen in strichliste:  # zeichen zuvor schonmal gesehen, deshalb schon in strichliste
            strichliste[zeichen] += 1  # Wert in der strichliste um 1 erhöhen
        else:  # zeichen haben wir noch nie gesehen, also nicht in strichliste
            strichliste[zeichen] = 1  # neuen Eintrag in der Strichliste mit Wert 1 anlegen

    return strichliste

variante1()
variante2()
