class Kalender(object):
    def __init__(self, jahr, monat, tag):
        self.jahr = jahr
        self.monat = monat
        self.tag = tag

    def __repr__(self):
        # return "Es wurden " + str(anzahl) + " Dateien ausgewertet"
        # return "Es wurden %i Dateien ausgewertet" % anzahl
        # return f"Es wurden {anzahl} Dateien ausgewertet"
        # return str(self.tag) + "." + str(self.monat) + "." + str(self.jahr)
        # return "%02i.%02i.%04i" % (self.tag, self.monat, self.jahr)
        return f"{self.tag:02d}.{self.monat:02d}.{self.jahr:04d}"

    def ist_schaltjahr(self):
        return self.jahr % 400 == 0 or (self.jahr % 100 != 0 and self.jahr % 4 == 0)

    TAGE_PRO_MONAT = (None, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    #                  0     1   2   3   4   5   6   7   8   9  10  11  12

    def naechsterTag(self):
        self.tag += 1

        if self.ist_schaltjahr() and self.monat == 2:
            korrektur = 1
        else:
            korrektur = 0

        if self.tag > Kalender.TAGE_PRO_MONAT[self.monat] + korrektur:
            self.tag = 1
            self.monat += 1
            if self.monat > 12:
                self.monat = 1
                self.jahr += 1


k = Kalender(2024, 2, 28)
print(k)
k.naechsterTag()
print(k)
