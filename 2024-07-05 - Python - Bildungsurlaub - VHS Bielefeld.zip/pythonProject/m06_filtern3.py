temperaturen = [-12, 5, 23, 17, 25]

def groesserGleich20(temperatur):
    return temperatur >= 20

def teilbarDurch2(temperatur):
    return temperatur % 2 == 0

def filtern(liste, kriterium):
    gefiltert = []
    for element in liste:
        if kriterium(element):
            gefiltert.append(element)

    return gefiltert

print(filtern(temperaturen, groesserGleich20))
print(filtern(temperaturen, teilbarDurch2))
