temperaturen = [-12, 5, 23, 17, 25]

def groesserGleich20(temperatur):
    return temperatur >= 20

print(list(filter(groesserGleich20, temperaturen)))
print(list(filter(lambda temperatur: temperatur % 2 == 0, temperaturen)))

