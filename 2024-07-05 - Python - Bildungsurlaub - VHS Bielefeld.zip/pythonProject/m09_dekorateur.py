from functools import cache

@cache
def fib_rekursiv(n):
    if n >= 2:
        return fib_rekursiv(n - 1) + fib_rekursiv(n - 2)
    else:
        return 1

@cache
def fakultaet(n):
    if n >= 1:
        return n * fakultaet(n - 1)
    else:
        return 1

print(fib_rekursiv(42))
