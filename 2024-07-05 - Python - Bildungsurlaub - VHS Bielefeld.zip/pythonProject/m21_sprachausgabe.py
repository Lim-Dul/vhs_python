import pyttsx3

# Initialisiere die Text-to-Speech-Engine
engine = pyttsx3.init()

# Setze den Text, der gesprochen werden soll
text = "Hallo, wie geht es dir?"

# Lass den Text sprechen
engine.say(text)

# Warte, bis die Sprachausgabe fertig ist
engine.runAndWait()

print("Fertig!")
