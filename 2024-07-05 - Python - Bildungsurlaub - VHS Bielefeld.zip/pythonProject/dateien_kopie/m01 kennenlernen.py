from collections import Counter
from statistics import mean

# Listen erkennen wir an eckigen Klammern. Listeneinträge werden durch Kommata getrennt.
# Hier: Die Anweisung rechts vom Gleichheitszeichen definiert eine Liste von Zeichenketten (erkennbar an Anführungszeichen).
# Durch das Gleichheitszeichen wird eine Variable vornamen definiert, der die Liste zugewiesen wird.
# Daher heißt diese Anweisung auch "Zuweisung".
vornamen = ["Felix", "Jan", "Christian", "Friederike", "Dirk", "Alina", "Tobias", "Dirk", "Irene", "Sabine", "Francisco", "Daniel"]
# Hier: Wir legen eine Liste von Integer-Werten an.
altersangaben = [29, 40, 59, 35, 31, 27, 32, 51, 44, 35, 47, 41]
orte = ["Bad Salzuflen", "Dietzenbach", "Bielefeld", "Bielefeld", "Spenge", "Bielefeld", "Bielefeld",
        "Schloss Holte-Stukenbrock", "Berlin", "Hannover", "Bielefeld", "Bielefeld"]

# 1) Durchschnittsalter
# a) Summe der Altersangaben durch Anzahl der Altersangaben
# Hier: Wir verwenden die built-in Funktionen sum und len
durchschnitt = sum(altersangaben) / len(altersangaben)
print("Durchschnittsalter:", durchschnitt)

# b) mean-Funktion aus der Standardbibliothek statistics
durchschnitt = mean(altersangaben)
print("Durchschnittsalter:", durchschnitt)

# c) for-Schleife
# summe, anzahl = 0, 0
summe = 0
anzahl = 0

# Lies: Für (for) jedes alter in der Liste der altersangaben wiederhole die nachfolgenden Anweisungen im eingerückten Block
for alter in altersangaben:
    summe += alter  # Kurz für: summe = summe + alter
    anzahl += 1  # Kurz für: anzahl = anzahl + 1

durchschnitt = summe / anzahl
print("Durchschnittsalter:", durchschnitt)

# 2) Häufigster Buchstabe im Vornamen
# a) Vornamen mit Schleife zu einer einzigen Zeichenkette zusammensetzen
alle_vornamen = ""
for vorname in vornamen:
    alle_vornamen += vorname

strichliste = Counter(alle_vornamen)
print(alle_vornamen)
print(strichliste)

# b) join-Methode
# "".join(vornamen) fügt alle Listenelemente ohne Trennzeichen hintereinander
strichliste = Counter("".join(vornamen))
print(strichliste)


# 4) Vornamen in alphabetisch sortierter Reihenfolge ausgeben
print("vornamen aufsteigend sortiert:", sorted(vornamen))
print("vornamen absteigend sortiert:", sorted(vornamen, reverse=True))

# 5) Altersangaben sortiert ausgeben
print("altersangaben sortiert:", sorted(altersangaben))

# 6) Vornamen nach Alter sortiert ausgeben
# erzeugt eine Liste von 2-Tupeln aus vorname und altersangabe
print(list(zip(vornamen, altersangaben)))
print(sorted(zip(vornamen, altersangaben)))
print(sorted(zip(altersangaben, vornamen)))
print(sorted(zip(vornamen, altersangaben), key=lambda t: t[1]))

# 7) Vorname der jüngsten Person
print("Jüngste Person:", sorted(zip(altersangaben, vornamen))[0])
print("Jüngste Person:", min(zip(altersangaben, vornamen)))

# 8) Anzahl der Teilnehmenden
print("Anzahl Teilnehmende:", len(vornamen))

# 9) Anzahl unterschiedlicher Wohnorte
# Idee: Nutze die built-in Funktion set um eine Menge aus der Liste der Orte zu erzeugen.
# Mengen haben die Eigenschaft, dass keine Duplikate vorkommen können.
print(set(orte))
print("Anzahl unterschiedlicher Wohnorte:", len(set(orte)))

# 3) Häufigkeit der Wohnorte
# 10) Häufigster Wohnort
strichliste = Counter(orte)
print(strichliste)
print(strichliste.most_common(1))
