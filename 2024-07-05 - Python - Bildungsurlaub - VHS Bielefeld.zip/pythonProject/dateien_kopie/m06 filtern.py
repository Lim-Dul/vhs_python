temperaturen = [-12, 5, 23, 17, 25]

# Aufgabe: Erzeuge eine neue Liste gefiltert, die nur Temperaturen >= 20 enthält.
# a) for-Schleife
gefiltert = []
for temperatur in temperaturen:
    if temperatur >= 20:
        gefiltert.append(temperatur)

print(gefiltert)

# b) List Comprehension
gefiltert = [temperatur for temperatur in temperaturen if temperatur >= 20]
print(gefiltert)

# c) Eigene Funktion filtern definieren
# Das Schlüsselwort def leitet die Definition einer neuen Funktion ein.
# Die Funktion hat einen Namen. Hier: filtern
# Auf den Namen folgt ein Paar runder Klammern in dem ggf. sogenannte Parameter/Argumente definiert werden.
# Der Doppelpunkt leitet den nachfolgenden Block ein, in dem die Implementierung der Funktion steht.
def filtern(liste):
    gefiltert = []
    for element in liste:
        if element >= 20:
            gefiltert.append(element)

    return gefiltert

print(filtern(temperaturen))
