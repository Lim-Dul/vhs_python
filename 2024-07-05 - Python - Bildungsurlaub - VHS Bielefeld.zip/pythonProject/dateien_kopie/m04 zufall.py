from random import randint, choice, sample

augenzahl = randint(1, 6)
print(augenzahl)

# Lotto-Ziehung "6 aus 49":
# Schreibe ein Programm, das 6 verschiedene zufällige Zahlen zwischen 1 und 49 ausgibt.

# a)
gezogene = []  # Die Liste der gezogenen Kugeln ist anfangs leer.
while len(gezogene) < 6:
    lottozahl = randint(1, 49)
    if lottozahl not in gezogene:
        gezogene.append(lottozahl)  # lottozahl ans Ende der Liste gezogene anhängen
        # print(lottozahl)

print(sorted(gezogene))

# b)
topf = list(range(1, 50))
ziehung = []

for i in range(6):
    a = choice(topf)
    topf.remove(a)
    ziehung.append(a)

print(sorted(ziehung))

# c)
lottozahlen = []
for i in range(6):
    gezogene_zahl = randint(1, 49)
    while gezogene_zahl in lottozahlen:
        gezogene_zahl = randint(1, 49)
    lottozahlen.append(gezogene_zahl)

print(sorted(lottozahlen))

# d)
topf = range(1, 50)
lottozahlen = sample(topf, k=6)
print(sorted(lottozahlen))
