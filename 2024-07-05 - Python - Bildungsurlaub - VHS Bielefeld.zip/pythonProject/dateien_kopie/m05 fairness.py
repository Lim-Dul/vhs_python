from collections import Counter
from random import randint

augenzahl = randint(1, 6)

# Ist der Würfel fair?
augenzahlen = []

n = 1_000_000
for i in range(n):
    augenzahlen.append(randint(1, 6))

strichliste = Counter(augenzahlen)
print(sorted(strichliste.items()))
for augenzahl, anzahl in sorted(strichliste.items()):
    print("Augenzahl:", augenzahl, "Anzahl %:", anzahl / n * 100)

