def is_isogram(string):
    string = string.replace("-", "")  # Bindestriche entfernen
    string = string.replace(" ", "")  # Leerzeichen entfernen
    string = string.lower()  # In Kleinbuchstaben umwandeln

    # print(string)
    # print(set(string))
    # print(len(string))
    # print(len(set(string)))
    # print(len(string) == len(set(string)))

    return len(string) == len(set(string))  # gibt es Duplikate?

print(is_isogram("Alphbet"))
