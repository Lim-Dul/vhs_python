from datetime import date, datetime
import json

class Teilnehmer(object):
    def __init__(self, vorname, geburtsdatum, ort):
        self.vorname = vorname
        self.geburtsdatum = geburtsdatum
        self.ort = ort

    def alter(self):
        datum = self.geburtsdatum
        heute = date.today()
        jahre = heute.year - datum.year
        if (heute.month, heute.day) < (datum.month, datum.day):  # hatte er noch nicht Geburtstag?
            jahre -= 1

        return jahre

    def to_dict(self):
        return {"vorname": self.vorname,
                "geburtsdatum": str(self.geburtsdatum),
                "ort": self.ort}

    @staticmethod
    def from_dict(d):
        return Teilnehmer(d["vorname"], datetime.strptime(d["geburtsdatum"], "%Y-%m-%d").date(), d["ort"])

    def __repr__(self):
        return "Teilnehmer[vorname:%s,geburtsdatum:%s,ort:%s]" % (self.vorname, self.geburtsdatum, self.ort)

t1 = Teilnehmer("Felix", date(1994, 12, 1), "Bad Salzuflen")
t2 = Teilnehmer("Jan", date(1983, 7, 4), "Dietzenbach")

teilnehmerliste = [t1, t2]

# Schreiben
with open("teilnehmer.json", "w") as datei:
    json.dump([teilnehmer.to_dict() for teilnehmer in teilnehmerliste], datei, indent=4)

# Lesen
with open("teilnehmer.json", "r") as datei:
    objekt = json.load(datei)
    teilnehmerliste = []
    for d in objekt:
        teilnehmerliste.append(Teilnehmer.from_dict(d))

print(teilnehmerliste)
