from datetime import date

def alter(teilnehmer):
    datum = teilnehmer["geburtsdatum"]
    heute = date.today()
    jahre = heute.year - datum.year
    if (heute.month, heute.day) < (datum.month, datum.day):  # hatte er noch nicht Geburtstag?
        jahre -= 1

    return jahre

t1 = {"vorname": "Felix", "geburtsdatum": date(1994, 12, 1), "ort": "Bad Salzuflen"}
t2 = {"vorname": "Jan", "geburtsdatum": date(1983, 7, 4), "ort": "Dietzenbach"}

teilnehmerliste = [t1, t2]

# Wie alt sind Jan und Felix jeweils?
print(alter(teilnehmerliste[0]))
print(alter(teilnehmerliste[1]))
