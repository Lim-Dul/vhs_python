import requests
import locale

locale.setlocale(locale.LC_ALL, 'de_DE.UTF-8')

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0"
}

url1 = "https://www.amazon.de/LEGO-75288-Action-Set-kreatives-Spielerlebnis/dp/B0813Q5JKX/"
url2 = "https://www.amazon.de/Dive-Into-Python-Books-Professionals/dp/1430224150/"
urls = [url1, url2]

# for url in urls:
#     res = requests.get(url, headers=headers)
#     txt = res.text
#     with open(file="lego.html", mode="w", encoding="utf8") as f:
#         f.write(txt)

prices = {}
with open(file="lego.html", mode="r", encoding="utf8") as f:
    txt = f.read()
    price_key = "displayPrice"
    pos_start = txt.index(price_key)
    pos_ende = txt.index("€", pos_start)
    price_txt = txt[pos_start + len(price_key) + 3:pos_ende - 1]
    price = locale.atof(price_txt)
    prices["Lego"] = price

print(prices)

