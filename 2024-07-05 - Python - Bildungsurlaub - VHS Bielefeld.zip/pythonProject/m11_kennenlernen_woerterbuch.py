# vornamen = ["Felix", "Jan", "Christian", "Friederike", "Dirk", "Alina", "Tobias", "Dirk", "Irene", "Sabine", "Francisco", "Daniel"]
# altersangaben = [29, 40, 59, 35, 31, 27, 32, 51, 44, 35, 47, 41]
# orte = ["Bad Salzuflen", "Dietzenbach", "Bielefeld", "Bielefeld", "Spenge", "Bielefeld", "Bielefeld",
#         "Schloss Holte-Stukenbrock", "Berlin", "Hannover", "Bielefeld", "Bielefeld"]

t1 = {"vorname": "Felix", "alter": 29, "ort": "Bad Salzuflen"}
t2 = {"vorname": "Jan", "alter": 40, "ort": "Dietzenbach"}

teilnehmerliste = [t1, t2]

# Vorname des zweiten Teilnehmers in der Teilnehmerliste:
print(teilnehmerliste[1]["vorname"])

# Felix zieht um nach Frankfurt:
print(teilnehmerliste[0]["ort"])
teilnehmerliste[0]["ort"] = "Frankfurt"
print(teilnehmerliste[0]["ort"])

