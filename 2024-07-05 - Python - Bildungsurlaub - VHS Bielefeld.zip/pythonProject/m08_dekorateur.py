# Definition eines Dekorateurs
def mach_schoener(funktion):
    d = {}

    def schoenere_funktion(n):
        if n in d:
            return d[n]
        else:
            d[n] = funktion(n)
            return d[n]

    return schoenere_funktion

@mach_schoener
def fib_rekursiv(n):
    if n >= 2:
        return fib_rekursiv(n - 1) + fib_rekursiv(n - 2)
    else:
        return 1

print(fib_rekursiv(42))
